
var _LANGUAGE 				= 'nl_NL'; //or: en_US, fr_FR, hu_HU
var _HOST_DOMOTICZ		  	= 'http://192.168.1.3:8084';
var _USE_AUTO_POSITIONING 	= true; //don't want to configure positions, use auto positioning
var _USE_FAVORITES			= true; //only used when using auto positioning


